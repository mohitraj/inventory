from django.db import models
from django.contrib.auth.models import User

class LABS(models.Model):
	lab_name = models.CharField(max_length=100,default="ABC")
	room_no = models.CharField(max_length=100,null=False)
	photo = models.ImageField(upload_to="myimage",default='default.jpg')

	def __str__(self):
		return str(self.room_no)

class Inventorydb(models.Model):

	comp_model = models.CharField(max_length=100, null=False)
	cpu = models.CharField(max_length=100, null=False)
	serial_cpu= models.CharField(max_length=100, null=False, unique=True)
	ram = models.CharField(max_length=100, null=False)
	hdd = models.CharField(max_length=100, null=False)
	tft_serial = models.CharField(max_length=100, null=False,unique=True)
	keyboard = models.CharField(max_length=100, null=False)
	mouse = models.CharField(max_length=100, null=False)
	lab_number = models.ForeignKey(LABS, on_delete=models.CASCADE)
	time1 = models.IntegerField(null=False, default=11)

	def __str__(self):
		return str(self.id)+"||"+str(self.comp_model)+","+str(self.cpu)+","+str(self.serial_cpu)+","+str(self.ram)+","+str(self.hdd)+","+str(self.tft_serial)+","+str(self.keyboard)+","+str(self.mouse)




class LAB_assign(models.Model):
	instructor  = models.ForeignKey(User, on_delete=models.CASCADE,related_name='lab_assign')
	lab =  models.ForeignKey(LABS, on_delete=models.CASCADE,related_name='lab_assign')

	def __str__(self):
		return str(self.lab)
