from django.contrib import admin 
from django.urls import path, include
from . import views 

urlpatterns = [ 
    path('mylab/', views.mylab, name='mylab'),
    path('lab_inv/', views.InventoryFormDisplay, name='labinv'),
    path('lab_inv1/<int:id>', views.LabDisplayUser, name='labdis'),
    path('csv_write/<int:id>', views.csv_write, name='csv_write'),
    path('bulk/<int:id>', views.bulk_upload, name='bulk'),
    path('bulk/update/<int:id>/', views.UpdateInventory, name='UpdateInventory'),
    path('bulk_display/', views.bulk_display, name='bulk_display'),
    #path('allinv/',views.InventoryListView.as_view(), name='invlist'),
    path('labins/',views.LabInstructor, name = 'labins'),
    path('labassign/',views.LabAssign, name = 'labassign'),
    path('AddLab/',views.AddLab, name = 'addlab'),
    path('addinst/',views.AddInst, name = 'addinst'),
    path('labins/delete/<int:id1>/',views.DeleteAssignedLAB, name = 'deleteassignedlab'),
    path('alllabs/',views.AllLAB, name = 'alllab'),
    path('showlabs/',views.showlabs, name = 'showlabs'),




]