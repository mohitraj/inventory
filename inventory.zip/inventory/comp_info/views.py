from django.shortcuts import render,get_object_or_404,redirect
from .models import LAB_assign,LABS,Inventorydb
from .forms import InventoryForm, LabAssignForm, LABSForm, ALLLABSForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
import time 
import csv,io
from django.http import HttpResponse
from .logger1 import logger 
from django.views.generic import ListView
from django.contrib.auth.decorators import permission_required,login_required
from django.contrib.auth.mixins import PermissionRequiredMixin,LoginRequiredMixin
from user_app.models import myProfile
# Create your views here.

def e_h(t1):
	t9 = time.localtime(t1)
	return time.strftime('%d-%m-%Y-%H')

def mylab(request):
	user1=request.user
	#name = LAB_assign.objects.filter(instructor_id__username=user1)
	#list_labs = [each.lab_id  for each in name]
	#n1 = LABS.objects.filter(id__in=list_labs)
	#lab = [(each.id,each.room_no) for each in n1]
	lab = user1.lab_assign.all()
	context = {'lab': lab, 'legend' : "My LAB"}
	return render(request, 'comp_info/mylab.html', context)

def LabDisplayUser(request,id):
	n1 = LABS.objects.filter(id=id)[0]
	#lab =n1.room_no
	data = Inventorydb.objects.filter(lab_number=id)
	context = {'data': data, 'n1':n1, 'id':id}
	return render(request, 'comp_info/showinv.html', context)


def InventoryFormDisplay(request):
	user1=request.user
	name = LAB_assign.objects.filter(instructor_id__username=user1)
	list_labs = [each.lab_id  for each in name]
	n1 = LABS.objects.filter(id__in=list_labs)
	groupChoices = [(int(each.id), each.room_no) for each in n1]
	print ("(****",groupChoices)
	
	if request.method =='POST':
		print ("okkkkkkkkkkk")
		form =   InventoryForm(groupChoices, request.POST)
		print ("okkkkkkkkkkkkllllllllllll")
		print ("hhhhhhh",form)
		if form.is_valid():

			if True :
				#print ("mark1.lab_number222")
				mark1 = form.save(commit=False)
				mark1.time1 = int(time.time())
				#print ("cleaend", form.cleaned_data.get('lab_number1',"okkkkjiii"))
				mark1.lab_number = get_object_or_404(LABS, id=form.cleaned_data.get('lab_number1'))
				#print ("mark1.lab_number1111", mark1.lab_number)
				mark1.save()
				messages.success(request,"Computer added")
			#except Exception as e :
			#	messages.warning(request,str(e))

	form =   InventoryForm(groupChoices)
	context = {'form':form }
	return render (request,'comp_info/displayform.html', context)

def UpdateInventory(request,id):
	user1=request.user
	name = LAB_assign.objects.filter(instructor_id__username=user1)
	list_labs = [each.lab_id  for each in name]
	n1 = LABS.objects.filter(id__in=list_labs)
	groupChoices = [(int(each.id), each.room_no) for each in n1]
	print ("(****",groupChoices)
	context = {}
	obj1 = get_object_or_404(Inventorydb, id =id )
	obj2 = str(obj1)
	form =   InventoryForm(groupChoices, request.POST or None, instance=obj1)
	if form.is_valid():
		form.save() 
		messages.success(request,"Computer Updated")
				
		logger.info(f"{user1}, {obj2} --> {obj1}")
		#print (form.cleaned_data.values())
	context["form"] = form
	return render (request,'comp_info/displayform.html', context)

def csv_write(request,id):
    # Create the HttpResponse object with the appropriate CSV header.
    obj1=LABS.objects.filter(id=id)[0]
    file_name = obj1.room_no+".csv"
    response = HttpResponse(
        content_type='text/csv',
        headers={'Content-Disposition': f'attachment; filename={file_name}'},
    )
    data = Inventorydb.objects.filter(lab_number=id)
    writer = csv.writer(response)
    writer.writerow(['comp_model','cpu', 'serial_cpu', 'ram', 'hdd', 'tft_serial', 'keyboard' , 'mouse',  'Date' ])
    for each in data:
    	#print (each)
    	writer.writerow([each.comp_model,each.cpu, each.serial_cpu, each.ram, each.hdd, each.tft_serial, each.keyboard , each.mouse , e_h(each.time1) ])


    return response

def bulk_upload(request,id):
	if request.method == "GET":
		prompt = {'order': 'Order of the CSV should be comp_model,cpu, serial_cpu,ram, hdd, tft_serial, keyboard, mouse'}
		return render(request, 'comp_info/bulk.html', prompt)

	csv_file = request.FILES['file']
	# let's check if it is a csv file
	if not csv_file.name.endswith('.csv'):
		messages.error(request, 'THIS IS NOT A CSV FILE')
	data_set = csv_file.read().decode('UTF-8')
	# setup a stream which is when we loop through each line we are able to handle a data in a stream
	io_string = io.StringIO(data_set)
	next(io_string)
	for column in csv.reader(io_string, delimiter=',', quotechar="|"):
		_, created = Inventorydb.objects.update_or_create(
		comp_model =column[0],
		cpu =column[1],
		serial_cpu=column[2],
		ram =column[3],
		hdd =column[4],
		tft_serial = column[5],
		keyboard = column[6],
		mouse = column[7],
		lab_number = get_object_or_404(LABS, id=id),
		time1 = int(time.time())
		)
	messages.error(request, 'Uploaded done')
	context = {}
	return render(request, 'comp_info/bulk.html', context)


@login_required(login_url='login')
#@permission_required('comp_info.add_LAB_assign',login_url='login')
def bulk_display(request):
	user1=request.user
	name = LAB_assign.objects.filter(instructor_id__username=user1)
	list_labs = [each.lab_id  for each in name]
	n1 = LABS.objects.filter(id__in=list_labs)
	lab = [(each.id,each.room_no) for each in n1]
	context = {'lab': lab, 'legend' : "My LAB"}
	return render(request, 'comp_info/bulk_display.html', context)

'''
def LabInstructor(request):
	list1 = []
	for each in LABS.objects.all():
		for i in each.lab_assign.all():
			list1.append((each, i))
	context = {'data': list1}
	return render(request,'comp_info/labins.html',context)
'''

def LabInstructor(request):
	list1 = []
	#for each in LABS.objects.all():
	list1 = LAB_assign.objects.all()
		
	context = {'data': list1}
	return render(request,'comp_info/labins.html',context)

def LabAssign(request):
	form = LabAssignForm()
	context = {"form": form, 'legend': "Assign Now"}
	if request.method == 'POST':
		form = LabAssignForm(request.POST)
		if form.is_valid():
			form.save()
			messages.success(request,"LAB Assigned")
	return render(request,'comp_info/displayform.html',context)

def AddLab(request):
	form = LABSForm()
	context = {"form": form, 'legend': "Add LAB"}
	if request.method == 'POST':
		form = LABSForm(request.POST,files= request.FILES)
		if form.is_valid():
			form.save()
			messages.success(request,"LAB Added")
	return render(request,'comp_info/displayform_labs.html',context)

def AddInst(request):
	form = UserCreationForm()
	context = {'form': form, 'legend': "Add Lab Instructor"}
	if request.method  == 'POST':
		form = UserCreationForm(request.POST)
		if form.is_valid():
			form.save()
			username = form.cleaned_data.get('username')
			#form.save()
			user1=get_object_or_404(User,username=username)
			messages.success(request,f"Account created {username}")
			myProfile.objects.create(user=user1)
	return render(request,'comp_info/displayform.html',context)

def DeleteAssignedLAB(request,id1):
	context = {}
	if request.method=='POST':
		LAB_assign.objects.filter(id=id1).delete()
		messages.success(request,f"Deleted")
		return redirect('labins')
		#return render(request,'comp_info/labins.html',context)
	return render(request, "comp_info/delete_view.html", context)

def AllLAB(request):
	form = ALLLABSForm()
	context = {"form": form, 'legend': "All LABS"}
	if request.method == 'POST':
		form = ALLLABSForm(request.POST)
		
		n1= (form.data['lab_number'])	

		data = Inventorydb.objects.filter(lab_number=n1)
		context = {"form": form,'data': data, 'n1':n1, 'id':n1}
		return render(request, 'comp_info/showinv1.html', context)
	return render(request,'comp_info/displayform.html',context)



def showlabs(request):

	#for each in LABS.objects.all():
	list1 = LABS.objects.all()
		
	context = {'img': list1}
	return render(request,'comp_info/showlabs.html',context)