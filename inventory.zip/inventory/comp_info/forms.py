from django import forms
from .models import Inventorydb, LAB_assign, LABS

class InventoryForm(forms.ModelForm):
	#name = LAB_assign.objects.filter(instructor_id__username=user)
	#n1 = LABS.objects.filter(id=int(name[0].lab_id))
	#lab_choice = [(each.id, each.room_no) for each in n1]
	#lab_number = forms.ChoiceField(choices=[], widget=forms.RadioSelect, required=False)

	def __init__(self, groupChoices_, *args, **kwargs):
		super(InventoryForm, self).__init__(*args, **kwargs)
		self.fields['lab_number1'].choices = groupChoices_

	lab_number1= forms.ChoiceField()

	class Meta:
		model = Inventorydb
		fields = ['comp_model','cpu','serial_cpu','ram','hdd', 'tft_serial','keyboard','mouse','lab_number1']

class LabAssignForm(forms.ModelForm):
	class Meta:
		model = LAB_assign
		fields = "__all__"

class LABSForm(forms.ModelForm):
	class Meta:
		model = LABS
		fields = "__all__"

'''
class InventoryForm(forms.Form):
	def __init__(self, groupChoices, *args, **kwargs):
		super(InventoryForm, self).__init__(*args, **kwargs)
		self.fields['lab_number'].choices = groupChoices

	comp_model = forms.CharField(max_length=100)
	cpu = forms.CharField(max_length=100)
	serial_cpu= forms.CharField(max_length=100)
	ram = forms.CharField(max_length=100)
	hdd = forms.CharField(max_length=100)
	tft_serial = forms.CharField(max_length=100)
	keyboard = forms.CharField(max_length=100)
	mouse = forms.CharField(max_length=100)
	lab_number= forms.ChoiceField()
	time1 = forms.IntegerField()

	def __str__(self):
		return str(self.roll_number)

'''

class ALLLABSForm(forms.ModelForm):
	class Meta:
		model = Inventorydb
		fields = ["lab_number"]