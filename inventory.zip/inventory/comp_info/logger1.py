import logging
logger = logging.getLogger("Lets")
logger.setLevel(logging.INFO)
fh = logging.FileHandler("live1.log")
formatter = logging.Formatter('%(asctime)s -  %(message)s ')
#print (help(formatter))
fh.setFormatter(formatter)
logger.addHandler(fh)
