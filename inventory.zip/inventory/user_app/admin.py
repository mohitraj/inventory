from django.contrib import admin

from .models import myProfile

admin.site.register(myProfile)

# Register your models here.
