from django.db import models
from django.contrib.auth.models import User 
from comp_info.models import LABS

# Create your models here.


class ImageAll(models.Model):
	user =  models.ForeignKey(User, on_delete=models.CASCADE)
	photo = models.ImageField(upload_to="myimage")
	name = models.CharField(max_length=100,default="AAA")
	date = models.DateTimeField(auto_now_add=True,)
	

class ImageAllNEW(models.Model):
	user =  models.ForeignKey(User, on_delete=models.CASCADE)
	photo = models.ImageField(upload_to="myimage")
	name = models.CharField(max_length=100,default="AAA")
	date = models.DateTimeField(auto_now_add=True,)
	lab =  models.ForeignKey(LABS, on_delete=models.CASCADE,related_name='imageall')

