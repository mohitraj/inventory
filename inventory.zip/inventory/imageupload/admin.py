from django.contrib import admin
from .models import ImageAll 

@admin.register(ImageAll)
class ImageAdmin(admin.ModelAdmin):
	list_display = ['user','photo', 'date']

# Register your models here.
