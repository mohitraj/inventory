from django.shortcuts import render
from .forms import ImageForm, ALLLABSRegForm
from .models import ImageAllNEW
from comp_info.models import LAB_assign, LABS
# Create your views here.


def ImageUpload(request):
	list_labs =[each.lab_id for each in request.user.lab_assign.all()]
	print ("*********",list_labs)
	labs = LABS.objects.filter(id__in=list_labs)
	#groupChoices = labs
	#print (groupChoices)
	form = ImageForm(labs)
	if request.method == 'POST':
		#print ("***********",help(ImageForm))
		form = ImageForm(labs,data =request.POST, files= request.FILES)
		if form.is_valid():
			fm=form.save(commit=False)
			fm.user = request.user
			form.save()
			#myProfile.objects.create(user=request.user)
	img = ImageAllNEW.objects.all()
	context = {'form': form, 'img': img}
	return render (request,'imageupload/imageform.html', context)

def AllLABReg(request):
	form = ALLLABSRegForm()
	context = {"form": form, 'legend': "All LABS"}
	if request.method == 'POST':
		form = ALLLABSRegForm(request.POST)
		
		n1= (form.data['lab'])	
		print ("hhhh##",n1)
		img = ImageAllNEW.objects.filter(lab_id=n1)
		print ("###img", img)
		context = {'form': form, 'img': img}
		return render(request,'imageupload/imageform.html',context)

	return render(request,'imageupload/imageform.html',context)