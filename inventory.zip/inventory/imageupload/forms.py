from django import forms 
from .models import ImageAllNEW
from comp_info.models import LAB_assign
class ImageForm(forms.ModelForm):

	#lab= forms.ChoiceField()


	def __init__(self, groupChoices_=None, **kwargs):
		super(ImageForm, self).__init__(**kwargs)
		#print ("kkkkkkkkkkkk###########",groupChoices_)
		if groupChoices_:
			self.fields['lab'].queryset = groupChoices_

	class Meta:
		model = ImageAllNEW
		fields = ['photo','name','lab']

class ALLLABSRegForm(forms.ModelForm):
	class Meta:
		model = ImageAllNEW
		fields = ["lab"]